#!/usr/bin/env python3
"""Verify xFlowAiStudio project files against SHA256SUMS.txt."""
from pathlib import Path
import hashlib, sys
root = Path(__file__).resolve().parent
manifest = root / "SHA256SUMS.txt"
if not manifest.exists():
    print("ERROR: SHA256SUMS.txt is missing")
    sys.exit(2)
failed = False
for line in manifest.read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    expected, rel = line.split("  ", 1)
    path = (root / rel).resolve()
    if root not in path.parents and path != root:
        print(f"UNSAFE PATH: {rel}"); failed = True; continue
    if not path.is_file():
        print(f"MISSING: {rel}"); failed = True; continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        print(f"CHANGED: {rel}"); failed = True
if failed:
    print("Integrity check FAILED.")
    sys.exit(1)
print("Integrity check OK: all listed files match their saved SHA-256 hashes.")
