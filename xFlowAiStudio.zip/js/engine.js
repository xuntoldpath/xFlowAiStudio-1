/*
 * xFlow engine — runs in the page (MAIN world) at document_start.
 *
 * Google Flow asks VideoFxService.GetFlowAppConfig (rpcid cPZSdc) whether
 * this account's country is allowed. The answer is a protobuf bool that the
 * live app reads as field 31 (array index 30 — jspb stores field N at index
 * N-1). Until 16 Oct 2026 that call was XMLHttpRequest. Flow 20261016+ sends
 * it with fetch(), so an XHR-only hook never sees it and Flow stays on
 * /unsupported-country. AI Studio still uses XHR, which is why that site
 * kept working.
 *
 * The remote spec (path, rpcid, flag index) is delivered by link.js. This
 * file only rewrites that one response, in memory.
 */
(function () {
  'use strict';

  var SPEC_MSG = 'cfc-flow-spec';
  var SPEC_REQUEST = 'cfc-flow-spec-request';
  var DIAG_ATTR = 'data-flow-local-diagnostic';
  var FALLBACK_RPC = 'cPZSdc';

  function isValidSpec(spec) {
    return !!spec &&
      typeof spec === 'object' &&
      typeof spec.path === 'string' && spec.path.charAt(0) === '/' &&
      typeof spec.rpcids === 'string' && spec.rpcids.length > 0 &&
      typeof spec.tag === 'string' && spec.tag.length > 0 &&
      Number.isInteger(spec.flagIndex) && spec.flagIndex >= 0 &&
      Number.isInteger(spec.minLength) && spec.minLength > spec.flagIndex;
  }

  function rpcIdsOf(url) {
    var ids = [];
    url.searchParams.getAll('rpcids').forEach(function (value) {
      value.split(',').forEach(function (part) {
        part = part.trim();
        if (part) ids.push(part);
      });
    });
    return ids;
  }

  function parseUrl(input) {
    try {
      var raw = typeof input === 'string' ? input :
        (input && typeof input.url === 'string' ? input.url : String(input || ''));
      return new URL(raw, location.href);
    } catch (e) {
      return null;
    }
  }

  function isBatchPath(url, spec) {
    if (!url || url.origin !== location.origin) return false;
    if (spec && (url.pathname === spec.path || url.pathname.endsWith(spec.path))) return true;
    return url.pathname.indexOf('/data/batchexecute') !== -1;
  }

  /** True when this request is the Flow app-config call we are allowed to rewrite. */
  function matchesSpec(input, spec) {
    if (!isValidSpec(spec)) return false;
    var url = parseUrl(input);
    if (!isBatchPath(url, spec)) return false;
    return rpcIdsOf(url).indexOf(spec.rpcids) !== -1;
  }

  /**
   * Before the spec arrives, only config-shaped calls are worth waiting on.
   * Every other batchexecute (generation, upload, …) must go through untouched.
   */
  function mightBeConfig(input, spec) {
    var url = parseUrl(input);
    if (!isBatchPath(url, spec)) return false;
    var ids = rpcIdsOf(url);
    if (isValidSpec(spec)) return ids.indexOf(spec.rpcids) !== -1;
    return ids.indexOf(FALLBACK_RPC) !== -1;
  }

  function setFlag(payload, spec) {
    var i = spec.flagIndex;
    if (Array.isArray(payload) && payload.length > i &&
        (payload[i] === null || typeof payload[i] === 'boolean') &&
        payload.length >= spec.minLength) {
      var before = payload[i];
      payload[i] = true;
      return before;
    }
    // Short payloads park high field numbers in a trailing plain object.
    if (Array.isArray(payload) && payload.length > 0) {
      var last = payload[payload.length - 1];
      if (last && typeof last === 'object' && !Array.isArray(last)) {
        var keys = [String(i + 1), String(i)];
        for (var k = 0; k < keys.length; k++) {
          var key = keys[k];
          if (typeof last[key] === 'boolean' || last[key] === null) {
            var prev = last[key];
            last[key] = true;
            return prev;
          }
        }
      }
    }
    throw new Error('Unexpected config schema');
  }

  function measureOf(declared, line) {
    var byteLen = function (s) { return new TextEncoder().encode(s).length; };
    var charLen = function (s) { return s.length; };
    var fns = [byteLen, charLen];
    for (var i = 0; i < fns.length; i++) {
      var delta = declared - fns[i](line);
      if (delta === 0 || delta === 1 || delta === 2) return fns[i];
    }
    return null;
  }

  /**
   * Rewrite every cPZSdc / spec.tag block inside a batchexecute body and fix
   * the length prefix of each changed frame. Returns null when this body has
   * nothing to patch (so the caller leaves the response alone).
   */
  function patchBody(body, spec) {
    if (typeof body !== 'string' || !isValidSpec(spec)) {
      throw new Error('Unexpected config schema');
    }
    var lines = body.split('\n');
    var count = 0;
    var before;
    for (var i = 0; i < lines.length; i++) {
      if (lines[i].indexOf('[[') !== 0) continue;
      var parsed;
      try { parsed = JSON.parse(lines[i]); } catch (e) { continue; }
      if (!Array.isArray(parsed)) continue;
      var changed = false;
      for (var j = 0; j < parsed.length; j++) {
        var entry = parsed[j];
        if (!Array.isArray(entry) || entry[0] !== spec.tag || entry[1] !== spec.rpcids) continue;
        var encoded = typeof entry[2] === 'string';
        var payload;
        try { payload = encoded ? JSON.parse(entry[2]) : entry[2]; } catch (e) {
          throw new Error('Unexpected config schema');
        }
        before = setFlag(payload, spec);
        entry[2] = encoded ? JSON.stringify(payload) : payload;
        changed = true;
        count++;
      }
      if (!changed) continue;
      var originalLine = lines[i].replace(/\r$/, '');
      var declared = Number(lines[i - 1]);
      var next = JSON.stringify(parsed);
      if (Number.isFinite(declared)) {
        var measure = measureOf(declared, originalLine) || function (s) {
          return new TextEncoder().encode(s).length;
        };
        lines[i - 1] = String(declared + measure(next) - measure(originalLine));
      }
      lines[i] = next;
    }
    if (count < 1) return null;
    return { body: lines.join('\n'), before: before, count: count };
  }

  if (typeof window === 'undefined') {
    module.exports = {
      patchBody: patchBody,
      matchesSpec: matchesSpec,
      mightBeConfig: mightBeConfig,
      isValidSpec: isValidSpec
    };
    return;
  }

  if (window.__flowLocalDiagnostic) return;

  var diag = window.__flowLocalDiagnostic = { state: 'awaiting-spec', applied: 0 };
  var spec = undefined; // undefined = not yet told, null = server had nothing
  var specWaiters = [];

  function publish() {
    try { console.info('[CFC Flow]', JSON.stringify(diag)); } catch (e) {}
    var write = function () {
      try {
        document.documentElement.setAttribute(DIAG_ATTR, JSON.stringify(diag));
      } catch (e) {}
    };
    if (document.documentElement) write();
    else document.addEventListener('DOMContentLoaded', write, { once: true });
  }

  function setState(state, before) {
    diag.state = state;
    if (arguments.length > 1) diag.before = before;
    publish();
  }

  function resolveSpec(next) {
    if (spec !== undefined) return;
    spec = isValidSpec(next) ? next : null;
    if (spec) setState('armed');
    else if (next == null) setState('spec unavailable — inert');
    else setState('spec invalid — inert');
    var waiters = specWaiters;
    specWaiters = [];
    waiters.forEach(function (fn) { fn(spec); });
  }

  function waitForSpec(ms) {
    if (spec !== undefined) return Promise.resolve(spec);
    return new Promise(function (resolve) {
      var done = false;
      var finish = function (value) {
        if (done) return;
        done = true;
        resolve(value);
      };
      specWaiters.push(finish);
      setTimeout(function () { finish(spec || null); }, ms);
    });
  }

  publish();

  window.addEventListener('message', function (event) {
    if (event.source !== window) return;
    var data = event.data;
    if (!data || data.type !== SPEC_MSG) return;
    resolveSpec(data.spec);
  });

  var asks = 0;
  (function ask() {
    if (spec !== undefined || asks >= 40) {
      if (spec === undefined) resolveSpec(null);
      return;
    }
    asks++;
    try { window.postMessage({ type: SPEC_REQUEST }, location.origin); } catch (e) {}
    setTimeout(ask, 500);
  })();

  function patchedResponse(res, body) {
    var headers = new Headers(res.headers);
    headers.delete('content-length');
    headers.delete('content-encoding');
    return new Response(body, {
      status: res.status,
      statusText: res.statusText,
      headers: headers
    });
  }

  async function rewriteResponse(res, active) {
    var text;
    try { text = await res.clone().text(); } catch (e) { return res; }
    try {
      var patched = patchBody(text, active);
      if (!patched) return res;
      diag.applied += patched.count;
      setState('applied', patched.before);
      return patchedResponse(res, patched.body);
    } catch (e) {
      setState('schema mismatch — unchanged');
      return res;
    }
  }

  // --- fetch (Flow 20261016+) ------------------------------------------------
  var nativeFetch = globalThis.fetch;
  if (typeof nativeFetch === 'function' && !nativeFetch.__xflow) {
    var hookedFetch = function (input, init) {
      var pending;
      try { pending = nativeFetch.apply(this, arguments); }
      catch (e) { return Promise.reject(e); }
      if (!mightBeConfig(input, spec)) return pending;
      return pending.then(function (res) {
        return waitForSpec(8000).then(function (active) {
          if (!matchesSpec(input, active)) return res;
          return rewriteResponse(res, active);
        });
      });
    };
    hookedFetch.__xflow = true;
    globalThis.fetch = hookedFetch;
  }

  // --- XMLHttpRequest (older Flow, and AI Studio) ----------------------------
  var XHR = XMLHttpRequest.prototype;
  var nativeOpen = XHR.open;
  var urls = new WeakMap();
  var rewritten = new WeakMap();

  XHR.open = function (method, url) {
    try { urls.set(this, String(url)); } catch (e) { urls.set(this, ''); }
    rewritten.delete(this);
    return nativeOpen.apply(this, arguments);
  };

  function currentBody(xhr, original) {
    if (typeof original !== 'string') return original;
    var url = urls.get(xhr);
    if (!url) return original;
    // Spec not here yet: hide only the config response so the page cannot
    // cache the locked flag. Every other request is returned as-is.
    if (spec === undefined) {
      if (!mightBeConfig(url, undefined)) return original;
      return '';
    }
    if (!matchesSpec(url, spec)) return original;
    if (xhr.readyState === 3) return '';
    if (xhr.readyState !== 4) return original;
    if (rewritten.has(xhr)) return rewritten.get(xhr);
    try {
      var patched = patchBody(original, spec);
      var body = patched ? patched.body : original;
      rewritten.set(xhr, body);
      if (patched) {
        diag.applied += patched.count;
        setState('applied', patched.before);
      }
      return body;
    } catch (e) {
      rewritten.set(xhr, original);
      setState('schema mismatch — unchanged');
      return original;
    }
  }

  ['responseText', 'response'].forEach(function (prop) {
    var desc = Object.getOwnPropertyDescriptor(XHR, prop);
    if (!desc || !desc.get || !desc.configurable) return;
    Object.defineProperty(XHR, prop, {
      configurable: true,
      enumerable: desc.enumerable,
      get: function () {
        var original = desc.get.call(this);
        return currentBody(this, original);
      }
    });
  });
})();
